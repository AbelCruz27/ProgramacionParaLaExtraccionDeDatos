create definer = root@localhost view vistaclientesfacturasdetallada as
select `examen2`.`vcf`.`IDCliente`    AS `IDCliente`,
       `examen2`.`vcf`.`Nombre`       AS `Nombre`,
       `examen2`.`vcf`.`Apellido`     AS `Apellido`,
       `examen2`.`vcf`.`Direccion`    AS `Direccion`,
       `examen2`.`vcf`.`Ciudad`       AS `Ciudad`,
       `examen2`.`vcf`.`Estado`       AS `Estado`,
       `examen2`.`vcf`.`CodigoPostal` AS `CodigoPostal`,
       `examen2`.`vcf`.`IDFactura`    AS `IDFactura`,
       `examen2`.`vcf`.`FechaEmision` AS `FechaEmision`,
       `examen2`.`vcf`.`Total`        AS `Total`,
       `p`.`Nombre`                   AS `Producto`,
       `p`.`Marca`                    AS `Marca`,
       `p`.`Precio`                   AS `PrecioProducto`
from ((`examen2`.`vistaclientesfacturas` `vcf` join `examen2`.`ventas` `v`
       on ((`examen2`.`vcf`.`IDCliente` = `v`.`ClienteID`))) join `examen2`.`productos` `p`
      on ((`v`.`IDVenta` = `p`.`IDProducto`)));

