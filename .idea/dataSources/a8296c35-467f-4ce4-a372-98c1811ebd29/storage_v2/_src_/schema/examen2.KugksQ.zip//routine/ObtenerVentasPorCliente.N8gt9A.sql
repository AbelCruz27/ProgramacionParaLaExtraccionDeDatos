create
    definer = root@localhost procedure ObtenerVentasPorCliente(IN cliente_id int)
BEGIN
    SELECT V.IDVenta, V.Fechadeventa, C.Nombre AS NombreCliente, S.Direccion AS DireccionSucursal, E.Nombre AS NombreEmpleado
    FROM Ventas V
    INNER JOIN Clientes C ON V.ClienteID = C.IDCliente
    INNER JOIN Sucursales S ON V.SucursalID = S.IDSucursal
    INNER JOIN Empleados E ON V.EmpleadoID = E.IDEmpleado
    WHERE V.ClienteID = cliente_id;
END;

