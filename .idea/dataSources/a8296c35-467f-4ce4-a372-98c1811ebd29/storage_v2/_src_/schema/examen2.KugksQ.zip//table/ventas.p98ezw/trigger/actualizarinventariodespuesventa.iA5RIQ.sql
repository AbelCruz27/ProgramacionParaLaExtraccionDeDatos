create definer = root@localhost trigger ActualizarInventarioDespuesVenta
    after insert
    on ventas
    for each row
BEGIN
    DECLARE producto_id INT;
    DECLARE cantidad_venta INT;
    
    -- Obtener el ID del producto y la cantidad vendida de la nueva venta
    SELECT ProductoID, COUNT(*) INTO producto_id, cantidad_venta
    FROM DetallesVenta
    WHERE VentaID = NEW.IDVenta
    GROUP BY ProductoID;
    
    -- Actualizar la cantidad en el inventario
    UPDATE Inventario
    SET Cantidad = Cantidad - cantidad_venta
    WHERE ProductoID = producto_id
    AND SucursalID = NEW.SucursalID;
END;

