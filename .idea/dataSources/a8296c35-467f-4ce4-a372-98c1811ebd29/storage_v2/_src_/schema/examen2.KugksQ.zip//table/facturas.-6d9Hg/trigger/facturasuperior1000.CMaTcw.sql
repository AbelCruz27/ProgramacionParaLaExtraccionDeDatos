create definer = root@localhost trigger FacturaSuperior1000
    after insert
    on facturas
    for each row
BEGIN
    IF NEW.Total > 1000 THEN
        INSERT INTO Facturas_Superiores_1000 (IDFactura, FechaEmision, Total, ClienteID)
        VALUES (NEW.IDFactura, NEW.FechaEmision, NEW.Total, NEW.ClienteID);
    END IF;
END;

