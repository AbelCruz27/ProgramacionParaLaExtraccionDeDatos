create definer = root@localhost trigger RegistroFechaVenta
    before insert
    on ventas
    for each row
BEGIN
    -- Asignar la fecha y hora actual antes de la inserción
    SET NEW.Fechadeventa = NOW();
END;

