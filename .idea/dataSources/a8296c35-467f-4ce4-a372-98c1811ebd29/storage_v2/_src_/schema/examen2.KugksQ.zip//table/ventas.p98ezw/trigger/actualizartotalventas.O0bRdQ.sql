create definer = root@localhost trigger ActualizarTotalVentas
    after insert
    on ventas
    for each row
BEGIN
    UPDATE Clientes
    SET TotalVentas = (SELECT SUM(Total) FROM Ventas WHERE ClienteID = NEW.ClienteID)
    WHERE IDCliente = NEW.ClienteID;
END;

