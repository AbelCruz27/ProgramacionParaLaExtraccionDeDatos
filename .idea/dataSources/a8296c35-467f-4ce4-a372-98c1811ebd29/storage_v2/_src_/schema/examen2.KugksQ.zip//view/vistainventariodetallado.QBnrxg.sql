create definer = root@localhost view vistainventariodetallado as
select `i`.`IDInventario` AS `IDInventario`,
       `i`.`ProductoID`   AS `ProductoID`,
       `i`.`SucursalID`   AS `SucursalID`,
       `i`.`Cantidad`     AS `Cantidad`,
       `p`.`Nombre`       AS `NombreProducto`,
       `p`.`Marca`        AS `Marca`,
       `s`.`Direccion`    AS `DireccionSucursal`,
       `s`.`Ciudad`       AS `Ciudad`,
       `s`.`Estado`       AS `Estado`,
       `s`.`CodigoPostal` AS `CodigoPostal`
from ((`examen2`.`inventario` `i` join `examen2`.`productos` `p`
       on ((`i`.`ProductoID` = `p`.`IDProducto`))) join `examen2`.`sucursales` `s`
      on ((`i`.`SucursalID` = `s`.`IDSucursal`)));

