create definer = root@localhost view vistaclientesfacturas as
select `c`.`IDCliente`    AS `IDCliente`,
       `c`.`Nombre`       AS `Nombre`,
       `c`.`Apellido`     AS `Apellido`,
       `c`.`Direccion`    AS `Direccion`,
       `c`.`Ciudad`       AS `Ciudad`,
       `c`.`Estado`       AS `Estado`,
       `c`.`CodigoPostal` AS `CodigoPostal`,
       `f`.`IDFactura`    AS `IDFactura`,
       `f`.`FechaEmision` AS `FechaEmision`,
       `f`.`Total`        AS `Total`
from (`examen2`.`clientes` `c` join `examen2`.`facturas` `f` on ((`c`.`IDCliente` = `f`.`ClienteID`)));

